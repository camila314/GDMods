//
//  CustomTableHeader.m
//  gdmeditor
//
//  Created by Full Name on 6/13/20.
//  Copyright © 2020 camden314. All rights reserved.
//

#import "CustomTableHeader.h"

@implementation CustomTableHeader
-(NSFont*)font {
    return [NSFont fontWithName:@"Thonburi" size:15];
}
-(NSTextAlignment)alignment {
    return NSTextAlignmentCenter;
}
@end
