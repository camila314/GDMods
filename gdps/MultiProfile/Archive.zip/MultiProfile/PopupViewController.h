//
//  PopupViewController.h
//  MultiProfile
//
//  Created by Full Name on 9/21/20.
//  Copyright © 2020 camden314. All rights reserved.
//

#import <Cocoa/Cocoa.h>

NS_ASSUME_NONNULL_BEGIN

@interface PopupViewController : NSViewController
@property (weak) IBOutlet NSTextField *nameField;
@property (weak) IBOutlet NSTextField *urlField;
@end

NS_ASSUME_NONNULL_END
