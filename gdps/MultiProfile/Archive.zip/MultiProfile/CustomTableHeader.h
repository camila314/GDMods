//
//  CustomTableHeader.h
//  gdmeditor
//
//  Created by Full Name on 6/13/20.
//  Copyright © 2020 camden314. All rights reserved.
//

#import <Cocoa/Cocoa.h>

NS_ASSUME_NONNULL_BEGIN

@interface CustomTableHeader : NSTableHeaderCell

@end

NS_ASSUME_NONNULL_END
