//
//  struct.h
//  gdmeditor
//
//  Created by Full Name on 6/13/20.
//  Copyright © 2020 camden314. All rights reserved.
//

#ifndef struct_h
#define struct_h
typedef struct MacroType {
    double xpos;
    int key;
    bool down;
} MType;
#define MSIZE_T 1024
#endif /* struct_h */
